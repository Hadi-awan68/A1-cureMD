$(document).ready(function() {
    // Base URL for the API
    const apiUrl = 'http://localhost:5034/api/books';

    // Function to fetch books from the API
    function fetchBooks() {
        $.ajax({
            url: apiUrl,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                displayBooks(data, "#search-results"); // Display all books in search results section
            },
            error: function(xhr, status, error) {
                console.error("There was an error loading the books:", error);
            }
        });
    }

    // Function to search for a book by ID
    function searchBookById(bookId) {
        $.ajax({
            url: `${apiUrl}/${bookId}`,
            type: 'GET',
            dataType: 'json',
            success: function(book) {
                if (book) {
                    displayResults([book]); // Display the single book
                } else {
                    displayResults([]); // No book found
                }
            },
            error: function(xhr, status, error) {
                console.error("There was an error fetching the book by ID:", error);
                displayResults([]); // No book found
            }
        });
    }

    // Function to handle general search functionality
    function searchBooks(query) {
        $.ajax({
            url: `${apiUrl}?search=${encodeURIComponent(query)}`,
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                displayResults(data);
            },
            error: function(xhr, status, error) {
                console.error("There was an error searching for the books:", error);
            }
        });
    }

    // Function to delete a book by ID
    function deleteBook(bookId) {
        $.ajax({
            url: `${apiUrl}/${bookId}`,
            type: 'DELETE',
            success: function() {
                alert(`Book with ID ${bookId} has been deleted!`);
                // No automatic refresh of the book list here
            },
            error: function(xhr, status, error) {
                console.error("There was an error deleting the book:", error);
                alert("Error deleting book.");
            }
        });
    }

    // Display books in a list
    function displayBooks(books, containerSelector) {
        var container = $(containerSelector);
        container.empty();

        if (books.length > 0) {
            var booksHtml = "<ul>";
            books.forEach(function(book) {
                booksHtml += "<li>";
                booksHtml += "<img src='" + book.imageUrl + "' alt='" + book.title + "' style='width: 100px; height: 150px; display: block; margin: 0 auto;'>";
                booksHtml += "<h3>" + book.title + "</h3>";
                booksHtml += "<p><strong>Author:</strong> " + book.author + "</p>";
                booksHtml += "<p>" + book.description + "</p>";
                booksHtml += "</li>";
            });
            booksHtml += "</ul>";
            container.html(booksHtml);
        } else {
            container.html("<p>No books available.</p>");
        }
    }

    // Display search results
    function displayResults(results) {
        var resultsContainer = $("#search-results");
        resultsContainer.empty();

        if (results.length > 0) {
            var resultsHtml = "<ul>";
            results.forEach(function(book) {
                resultsHtml += "<li>";
                resultsHtml += "<img src='" + book.imageUrl + "' alt='" + book.title + "' style='width: 100px; height: 150px; display: block; margin: 0 auto;'>";
                resultsHtml += "<h3>" + book.title + "</h3>";
                resultsHtml += "<p><strong>Author:</strong> " + book.author + "</p>";
                resultsHtml += "<p>" + book.description + "</p>";
                resultsHtml += "</li>";
            });
            resultsHtml += "</ul>";
            resultsContainer.html(resultsHtml);
        } else {
            resultsContainer.html("<p>No results found.</p>");
        }
    }

    // Handle form submission for adding a new book
$("#add-book-form").on("submit", function(e) {
    e.preventDefault();

    var newBook = {
        title: $("#title").val(),
        author: $("#author").val(),
        description: $("#description").val(),
        imageUrl: $("#image-url").val(),
        price: "$" + (Math.floor(Math.random() * 30) + 10).toFixed(2) // Random price between $10 and $40
    };

    $.ajax({
        url: apiUrl,
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(newBook),
        success: function(data) {
            // Check the response data
            console.log('New book data:', data); // Log the response data

            // Alert message with book details
            alert(`Book added successfully! Title: ${data.title}, Author: ${data.author}`);
            
            // Ensure displayBooksTable function is defined or comment out if not needed
            // displayBooksTable([data]);

            $("#add-book-form")[0].reset(); // Clear the form
        },
        error: function(xhr, status, error) {
            console.error("There was an error adding the book:", error);
        }
    });
});

    // Handle search functionality
    $("#search-button").on("click", function() {
        var query = $("#search-bar").val().toLowerCase();

        if ($.isNumeric(query)) {
            // If the query is a number, assume it's a book ID
            searchBookById(query);
        } else {
            // Otherwise, perform a general search
            searchBooks(query);
        }
    });

    $("#search-bar").on("keypress", function(e) {
        if (e.which == 13) { // Enter key pressed
            $("#search-button").click();
        }
    });

    // Handle "View All" button click
    $("#view-all-button").on("click", function() {
        fetchBooks(); // Fetch all books and display them in the search results section
    });

   

    // Handle form submission for deleting a book
    $("#delete-book-form").on("submit", function(e) {
        e.preventDefault();
        
        var bookId = $("#book-id").val();
        
        if ($.isNumeric(bookId)) {
            $.ajax({
                url: `${apiUrl}/${bookId}`, // Ensure this URL is correct
                type: 'DELETE',
                success: function(data) {
                    console.log('Delete response data:', data); // Log the response data
                    alert(`Book with ID ${bookId} has been deleted!`);
                    // Optionally, fetch the book list if needed
                    // fetchBooks();
                },
                error: function(xhr, status, error) {
                    console.error("There was an error deleting the book:", error);
                    alert("Error deleting book.");
                }
            });
        } else {
            alert("Please enter a valid Book ID.");
        }
    });
});